const conexao = require("../conexao")

class Venda{
    add(venda){
        const sql = "INSERT INTO venda SET ?";
        conexao.query(sql, venda, (erro, resultado)=>{
            if(erro){
                console.log(erro)
            } else {
                console.log(resultado)
            }
        })
    }

    delete(id, res){
        const sql = "DELETE FROM venda where id=?"
        conexao.query(sql, id, (erro, resultado)=>{
            if(erro){
                res.status(404).json(erro)
            }
        })
    }

    alterar(id, valores, res){
        const sql = "UPDATE venda SET ? WHERE id=?"
        conexao.query(sql, [valores, id], (erro, resultado)=>{
            if(erro){
                res.status(404).json(erro)
            }
        })
    }
}

module.exports = new Venda