const conexao = require("../conexao")

class Carro{
    add(carro){
        const sql = "INSERT INTO carro SET ?";
        conexao.query(sql, carro, (erro, resultado)=>{
            if(erro){
                console.log(erro)
            } else {
                console.log(resultado)
            }
        })
    }

    delete(id, res){
        const sql = "DELETE FROM carro where id=?"
        conexao.query(sql, id, (erro, resultado)=>{
            if(erro){
                res.status(404).json(erro)
            }
        })
    }

    alterar(id, valores, res){
        const sql = "UPDATE carro SET ? WHERE id=?"
        conexao.query(sql, [valores, id], (erro, resultado)=>{
            if(erro){
                res.status(404).json(erro)
            }
        })
    }
}

module.exports = new Carro