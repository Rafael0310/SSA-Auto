// Configuração e Importações
const express = require("express")
const conexao = require ("./conexao")
const bodyParser = require("body-parser")
const Cliente = require("./modelo/cliente")
const Funcionario = require("./modelo/funcionario")
const Carro = require("./modelo/carro")
const Venda = require("./modelo/venda")

const app = express()

app.set("view engine", "ejs")

app.set("views", "./view")

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json())

// Conexão do Servidor
conexao.connect(servidor => {
    if(servidor){
        console.log(servidor)
    } else {
        app.listen(4000, ()=> console.log('servidor ON!'))
    }
})

// Routes
    app.get("/index", function(req, res){
        res.render("index")
    })

    app.get("/sobre", function(req, res){
        res.render("sobre")
    })

    app.get("/contatos", function(req, res){
        res.render("contatos")
    })
    
    // Funcionário
    app.get("/funcionario", function(req, res){
        conexao.query("SELECT * from funcionario", function(erro, resultado){
        res.render("funcionario", {data: resultado})
        })
        })

        app.post("/funcionario/cadastrar", (req,res)=>{
        const funcionario = req.body

        try{
            Funcionario.add(funcionario)
            conexao.query("SELECT * from funcionario", function(erro, resultado){
                res.render("funcionario", {data: resultado})
            })
        } catch(e) {
            console.log("Error: "+ e)
            }
        })

        app.post("/funcionario/deletar", (req,res) => {
            const id = Number(req.body.id)

            try{
                Funcionario.delete(id, res)
                conexao.query("SELECT * from funcionario", function(erro, resultado){
                    res.render("funcionario", {data: resultado})
                })
            } catch(e) {
                console.log("Error: "+ e)
            }
        })

        app.post("/funcionario/alterar", (req,res) => {
            const valores = req.body
            const id = parseInt(req.body.id)

            try{
                Funcionario.alterar(id, valores,res)
                conexao.query("SELECT * from funcionario", function(erro, resultado){
                    res.render("funcionario", {data: resultado})
                })
            } catch(e) {
                console.log("Error: "+ e)
            }
        })

        // Cliente
        app.get("/cliente", function(req, res){
            conexao.query("SELECT * from cliente", function(erro, resultado){
            res.render("cliente", {data: resultado})
            })
            })
            
            app.post("/cliente/cadastrar", (req,res)=>{
            const cliente = req.body

            try{
                Cliente.add(cliente)
                conexao.query("SELECT * from cliente", function(erro, resultado){
                    res.render("cliente", {data: resultado})
                })
            } catch(e) {
                console.log("Error: "+ e)
            }
            })
            
            app.post("/cliente/deletar", (req,res)=>{
            const id = Number(req.body.id)

            try{
                Cliente.delete(id, res)
                conexao.query("SELECT * from cliente", function(erro, resultado){
                    res.render("cliente", {data: resultado})
                })
            } catch(e) {
                console.log("Error: "+ e)
            }
            })
            
            app.post("/cliente/alterar", (req,res)=>{
            const valores = req.body
            const id = parseInt(req.body.id)

            try{
                Cliente.alterar(id, valores,res)
                conexao.query("SELECT * from cliente", function(erro, resultado){
                    res.render("cliente", {data: resultado})
                })
            } catch(e) {
                console.log("Error: "+ e)
            }
            })

        // Carro
        app.get("/carro", function(req, res){
            conexao.query("SELECT * from carro", function(erro, resultado){
                res.render("carro", {data: resultado})
            })
        })
        
        app.post("/carro/cadastrar", (req,res)=>{
            const carro = req.body
        
            try{
        
                Carro.add(carro)
                conexao.query("SELECT * from carro", function(erro, resultado){
                    res.render("carro", {data: resultado})
                })
        
            } catch(e) {
                console.log("Error: "+ e)
            }
        })
        
        app.post("/carro/deletar", (req,res)=>{
            const id = Number(req.body.id)
            
            try{
                Carro.delete(id, res)
                conexao.query("SELECT * from carro", function(erro, resultado){
                    res.render("carro", {data: resultado})
                })
            } catch(e) {
                console.log("Error: "+ e)
            }
        })
        
        app.post("/carro/alterar", (req,res)=>{
            const valores = req.body
            const id = parseInt(req.body.id)
        
            
            try{
                Carro.alterar(id, valores,res)
                conexao.query("SELECT * from carro", function(erro, resultado){
                    res.render("carro", {data: resultado})
                })
            } catch(e) {
                console.log("Error: "+ e)
            }
        })
        
        //Vendas
        app.get("/venda", function(req, res){
            conexao.query("SELECT * from venda", function(erro, resultado){
                res.render("venda", {data: resultado})
            })
        })
        
        app.post("/venda/cadastrar", (req,res)=>{
            const venda = req.body
        
            try{
        
                Venda.add(venda)
                conexao.query("SELECT * from venda", function(erro, resultado){
                    res.render("venda", {data: resultado})
                })
        
            } catch(e) {
                console.log("Error: "+ e)
            }
        })
        
        app.post("/venda/deletar", (req,res)=>{
            const id = Number(req.body.id)
            
            try{
                Venda.delete(id, res)
                conexao.query("SELECT * from venda", function(erro, resultado){
                    res.render("venda", {data: resultado})
                })
            } catch(e) {
                console.log("Error: "+ e)
            }
        })
        
        app.post("/venda/alterar", (req,res)=>{
            const valores = req.body
            const id = parseInt(req.body.id)
        
            
            try{
                Venda.alterar(id, valores,res)
                conexao.query("SELECT * from venda", function(erro, resultado){
                    res.render("venda", {data: resultado})
                })
            } catch(e) {
                console.log("Error: "+ e)
            }
        })