Sistema CRUD de Automóveis

Este é um sistema de gerenciamento de automóveis que permite a criação, leitura, atualização e exclusão de registros de automóveis em um banco de dados MySQL. O sistema utiliza as tecnologias EJS, Bootstrap 4 e MySQL.

Instalação

Clone o repositório em sua máquina local.
Certifique-se de ter o MySQL e o Node.js instalados em sua máquina.
Abra o terminal e navegue até o diretório raiz do projeto.
Execute o comando npm install para instalar as dependências necessárias.
Crie um banco de dados MySQL e atualize as credenciais no arquivo config/db.js com as suas próprias credenciais de banco de dados.
Execute o comando npm start para iniciar o servidor.

Uso

Abra o navegador e acesse http://localhost:3000 para acessar o sistema.
Na página inicial, você verá uma lista de automóveis registrados no banco de dados.
Clique no botão "Adicionar Automóvel" para criar um novo registro de automóvel.
Preencha as informações solicitadas no formulário e clique em "Salvar" para adicionar o registro ao banco de dados.
Você pode editar ou excluir registros existentes clicando nos botões correspondentes na tabela de automóveis.
Para sair do sistema, clique em "Logout" no canto superior direito da página.

Tecnologias utilizadas

Node.js
EJS
Bootstrap 4
MySQL